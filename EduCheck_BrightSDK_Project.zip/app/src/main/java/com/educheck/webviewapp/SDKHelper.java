package com.educheck.webviewapp;

import com.brd.sdk.main;

import android.app.Activity;
import android.content.Context;
import android.util.Pair;

public class SDKHelper {

    public static class Config {
        public String buttonColor = null;
        public String trackingId;
        public String tosUrl = null;
        public String declineOption = "ADS";
        public Runnable onOptIn = ()->{};
        public Runnable onOptOut = ()->{};
        public Pair<Integer, Integer> jobIdRange = new Pair<>(1, 1000);
    }

    static volatile SDKHelper instance = null;
    Runnable onSwitchOn;
    Runnable onSwitchOff;
    Config config;

    private SDKHelper(final Context a, Config config){
        this.config = config;
        main.set_button_color(config.buttonColor);
        main.set_decline_option(config.declineOption);
        main.set_tos_url(config.tosUrl);
        main.set_tracking_id(config.trackingId);
        main.set_jobid_range(config.jobIdRange.first, config.jobIdRange.second);
        main.set_choice_listener(i->{
            if (i==main.choice.PEER)
                config.onOptIn.run();
            else
                config.onOptOut.run();
        });
        if (a instanceof Activity)
            configureSwitch((Activity) a);
        start(a);
    }
    public void configureSwitch(Activity a){
        onSwitchOn = ()->showCustomConsentDialog(a);
        onSwitchOff = ()->{
            optOut(a);
            config.onOptOut.run();
        };
    }
    public void start(Context ctx){ main.start(ctx); }
    public void showDialog(Activity a){ showDialog(a, true); }
    public void showDialog(Activity a, boolean force){ main.show_dialog(a, force); }
    public void showDialogIfNeeded(Activity a){
        if (getStatus(a) == 0) { // Status 0 means no choice made yet
            showCustomConsentDialog(a);
        }
    }

    public void showCustomConsentDialog(final Activity activity) {
        final android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(activity);
        android.view.LayoutInflater inflater = activity.getLayoutInflater();
        android.view.View dialogView = inflater.inflate(R.layout.dialog_consent, null);
        builder.setView(dialogView);
        builder.setCancelable(false);

        final android.app.AlertDialog dialog = builder.create();

        dialogView.findViewById(R.id.btn_agree).setOnClickListener(v -> {
            main.report_dialog_display();
            main.set_choice(activity, main.choice.PEER);
            config.onOptIn.run();
            dialog.dismiss();
        });

        dialogView.findViewById(R.id.btn_dismiss).setOnClickListener(v -> {
            main.report_dialog_display();
            main.set_choice(activity, main.choice.NOT_PEER);
            config.onOptOut.run();
            dialog.dismiss();
        });

        dialog.show();
    }

    public void optOut(Context ctx){ main.opt_out(ctx); }
    public boolean isSdkProcess(){ return main.is_svc_process(); }
    public int getStatus(Context ctx){ return main.get_status(ctx); }
    public static synchronized void init(Context a, Config config){
        instance = new SDKHelper(a, config);
    }
    public static void reportDialogDisplay(){
        main.report_dialog_display(); }
    public static synchronized SDKHelper getInstance(){ return instance; }
}
