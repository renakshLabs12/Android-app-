# Bright SDK Application Creation Form Answers

Based on the screenshot provided, here are the required fields and the suggested values for your application:

| Field Name | Value |
| :--- | :--- |
| **Operating System** | **Android out of store** |
| **Name** | **EduCheck** (or your preferred official application name) |
| **Application ID** | **com.educheck.webviewapp** |
| **URL** | **[Direct Download Link]** (e.g., `https://yourdomain.com/downloads/educheck.apk`) |
| **Approximate DAU** | **75** (As shown in your screenshot) |
| **Approximate monthly installations** | **15** (As shown in your screenshot) |

### Important Note on the URL Field:
The **URL** field requires a link where the APK file will be hosted for download since you selected "Android out of store". Once you upload the APK I've prepared to your hosting or a file-sharing service, you should put that link here.

### Technical Details for your records:
- **Package Name / Application ID**: `com.educheck.webviewapp`
- **WebView URL**: `https://educheck33.oneapp.dev`
- **Features**: Full-screen mode, Splash screen (spinner loading), Bright SDK integration ready.
